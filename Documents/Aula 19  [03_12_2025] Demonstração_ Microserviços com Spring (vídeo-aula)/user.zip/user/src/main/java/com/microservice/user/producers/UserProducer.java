package com.microservice.user.producers;

import com.microservice.user.dtos.EmailDto;
import com.microservice.user.models.UserModel;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class UserProducer {

    @Autowired
    RabbitTemplate rabbitTemplate;

    @Value(value = "${broker.queue.email.name}")
    private String routingKey;

    // Método para converter e enviar a mensagem:
    public void publishMessageEmail(UserModel userModel) {

        // Preencher os dados do emailDto com os dados do userModel:
        String subject = "Cadastro realizado com sucesso!";
        String text = userModel.getName() + ", seja bem vindo(a)!\n"
        + "Agradecemos o seu cadastro, aproveite agora"
        + " todos os recursos da nossa plataforma!";

        var emailDto = new EmailDto(
                userModel.getUserId(),
                userModel.getEmail(),
                subject,
                text
        );

        rabbitTemplate.convertAndSend("", routingKey, emailDto);
    }
}

