package com.microservice.email.services;

import com.microservice.email.dtos.EmailRecordDto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.MailException;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

@Service
public class EmailService {

    // Aqui deveriamos injetar um objeto repository,
    // para poder gravar o email na base de dados.
    // Como falado, vamos apenas enviar o email,
    // não vamos salvar no banco de dados.

    @Autowired
    JavaMailSender emailSender;

    @Value(value = "${spring.mail.username}")
    private String emailFrom;

    public void sendEmail(EmailRecordDto emailRecordDto) {
        try{
            SimpleMailMessage message = new SimpleMailMessage();
            message.setTo(emailRecordDto.emailTo());
            message.setSubject(emailRecordDto.subject());
            message.setText(emailRecordDto.text());
            emailSender.send(message);

        } catch (MailException e){
            throw new RuntimeException("Erro ao enviar email", e);
        }
    }
}
